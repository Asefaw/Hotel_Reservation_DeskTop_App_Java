/*
Homw Work 2 Creating and testing a Class
 */
package BussinesClass;

 
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Asefaw Mekuria
 */
public class Employee {
            private String ssNumber;
            private String firstName;
            private String lastName;
            private String dateOfBirth;
            private Integer age;
            private String address;
            private String phone;
            private String email;
            private String jobTitle;
            private static Integer count = 0;
    
    public String getSSNumber(){
        return ssNumber;
    }
    public void setSSNumber(String ssn) {
        ssNumber = ssn;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String fName) {
        firstName = fName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lName) {
        lastName = lName;
    }
    public String getDateOfBirth() {
        return dateOfBirth;
    }
    public void setDateOfBirth(String dob){
        dateOfBirth = dob;
            int newAge;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            
            LocalDate birthDate = LocalDate.parse(dob, formatter);
            LocalDate currentDate = LocalDate.now();
            newAge = currentDate.getYear() - birthDate.getYear();
            age = newAge;
    }
    public Integer getAge(){
        return age;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String addr) {
        address = addr;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String telephone) {
        phone = telephone;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String Email) {
        email = Email;
    }
    public String getJobTitle(){
        return jobTitle;
    }
    public void setJobTitle(String title){
        jobTitle = title;
    }
    public static Integer getCount() {
        return count;
    }
    public static void setCount( Integer cnt) {
        count = cnt;
    }
    //Default Constractor
    public Employee() {
        ssNumber = "";
        firstName = "";
        lastName = "";
        dateOfBirth = "00/00/0000";
        age = 0;
        address = "";
        phone = "";
        email = "";
        jobTitle = "";
        count++;
    }
    //Parametrized Constractor
    public Employee(String SSN,String fName, String lName, String dob,String addr,String phone,String email,String title) {
        this.setSSNumber(SSN);
         this.setFirstName(fName);
         this.setLastName(lName);
         this.setDateOfBirth(dob);
         this.setAddress(addr);
         this.setPhone(phone);
         this.setEmail(email);
         this.setJobTitle(title);   
        count++;
    }
    public void print() throws IOException {
        try {
            
            try (PrintWriter outStream = new PrintWriter(
                    new BufferedWriter(
                            new FileWriter("Network_Printer.txt",true)))) {
                outStream.println("*******************************");
                outStream.println("First Name = "+firstName);
                outStream.println("Last Name = "+lastName);
                outStream.println("Social Security Number = "+ssNumber);
                outStream.println("Date of Birth = "+dateOfBirth);
                outStream.println("Address = "+address);
                outStream.println("Age = "+age);
                outStream.println("Email = "+email);
                outStream.println("Title = "+jobTitle);
                outStream.println("*******************************");
                outStream.println();
                outStream.println();
            }
            
        }catch(Exception e) {
            
        }
    }
    public void load() {
        String key = "";
        Database_Load(key);
    }
    public void insert() {
        Database_Insert();
    }
    public void update() {
        Database_Update();
    }
    public void delete() {
        String key = "";
        Database_Delete(key);
    }
    public void Database_Load(String input) {
        //not Implimented
    }
    public void Database_Insert() {
        //not Implimented
    }public void Database_Update() {
        //not Implimented
    }
    public void Database_Delete(String input) {
        //not Implimented
    }
    
}
