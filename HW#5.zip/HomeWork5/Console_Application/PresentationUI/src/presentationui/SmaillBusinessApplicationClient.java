/*
 *Small business
User Interface code
 */
package presentationui;
import BussinesClass.UserAccount;
import BussinesClass.UserAccountList;
import BussinesClass.Employee;
import BussinesClass.EmployeeList;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Asefaw Mekuria
 */
public class SmaillBusinessApplicationClient {

   
    public static UserAccountList objUserAccountList =  new UserAccountList();
    public static EmployeeList objEmployeeList = new EmployeeList();
    
    //Main method
     public static void main(String[] args) throws IOException, Exception {
        String userName, password; //to hold the user inputer;
        Scanner kb = new Scanner(System.in);
       
        
        System.out.println("Welcom to authentication portal");
        System.out.println("-------------------------------");
         System.out.println();
           System.out.println("Please enter your username");
            userName = kb.nextLine();
          System.out.println();
         System.out.println("Please enter your Password");
        password = kb.nextLine();
       System.out.println();
        
        while (!userName.equals("-1") || !password.equals("-1")) {
            if(Authenticate(userName, password)) {
                startMainMenuScreen();
            }
            else {
                System.out.println("Access Denied");
            }
            System.out.println();
            System.out.println("Welcom to authentication portal");
            System.out.println();
            System.out.println("Please enter your username");
            userName = kb.nextLine();
            System.out.println("Please enter your Password");
            password = kb.nextLine();
            Authenticate(userName, password);
        }
        System.out.println("Program is Exiting.......");
    }
     public static boolean Authenticate(String U, String P) {
        try{
            return objUserAccountList.authenticate(U, P);
        }
        catch(Exception e){
        }
        return false;
    }
     //Wlecome Screen Main menu
     public static int mainMenuScreen() {
         int option;
         Scanner kb = new Scanner(System.in);
         System.out.println();
         System.out.println("****Welcome to Small Business Application****");
         System.out.println("--------------------------------------------");
         System.out.println();
         System.out.println("1)---- Back-End Management Screen");
         System.out.println("2)---- Retail Point of Sale Screen");
         System.out.println("0)---- Exit");
         System.out.println();
         System.out.println("Please select an Option (1, 2, or 0)");
         System.out.println();
         option = kb.nextInt();
         return option;
     }

     //method below starts the main menu welcome Screen
     public static void startMainMenuScreen() throws Exception{ 
         int option = mainMenuScreen();
         
         while(option != 0) {
             if(option == 1){
                 startBackEndManagement();
             } else if(option == 2) {
                 startRetailPointOfSale();
             } else{
                 System.out.println("Incorrect Selection! Try again");
             }
             option = mainMenuScreen();

         }
         System.out.println("Exiting main menu scree.....");
     }
     
     //retail point of sale Screen
     public static int retailPointOfSale() {
         Scanner kb = new Scanner(System.in);
         int option;
         System.out.println();
         System.out.println("****Wlcome to Retail point of sale management*****");
         System.out.println("--------------------------------------------------");
         System.out.println("1)---- Register");
         System.out.println("0)---- Exit");
         System.out.println("Please select an Option 1, or 0");
         option = kb.nextInt();
          System.out.println();
         return option;
     }
     //method below starts the retail point of screen
     public static void startRetailPointOfSale() {

         int option = retailPointOfSale();
         while(option != 0){
            if(option == 1){
                System.out.println("Under Construction");
                System.out.println();
            } else {
                System.out.println("Incorrect selection TRY AGAIN");
               }
            option = retailPointOfSale();
         }
         System.out.println("exiting retail point of sale program");
         System.out.println(); 
    }
     
     //back end management screen
     public static int backEndManagement() {
         int option;
         System.out.println();
         Scanner kb = new Scanner(System.in);
         System.out.println("****Back End Management Screen****");
         System.out.println("-----------------------------------");
         System.out.println("1)---- User Acoount Management");
         System.out.println("2)---- Employee Management");
         System.out.println("0)---- Exit & Save");
         System.out.println();
         System.out.println("Please Select a Menu option (1, or 0");
         option = kb.nextInt();
         System.out.println();
         return option;
     }
     
     //method below starts the back end management screen
     public static void startBackEndManagement() throws Exception{
       
         int option = backEndManagement();
         while(option != 0) {
             switch(option){
                 case 1:
                     startUserAccountMangement();
                     break;
                 case 2:
                     startEmployeeManagement();
                     break;
                 default:
                     System.out.println("incorrect Selection please try again");
             }
             option = backEndManagement();
         }
         System.out.println("Exiting back end management program.... ");
         System.out.println();
     }
     
     //User account management screen
     public static int userAccountManagement(){
         Scanner kb = new Scanner(System.in);
        int option;
        System.out.println();
        System.out.println("***Welcome to the User Account Management Portal****");
         System.out.println("----------------------------------------------------");
        System.out.println("1)---- Search for user Account recored");
        System.out.println("2)----  Add a User Account record");
        System.out.println("3)----  Edit user Account recored");
        System.out.println("4)----  Remove user Account recored ");
        System.out.println("5)----  Change a User Name");
        System.out.println("6)----  Change a Password");
        System.out.println("7)----  Change an Email Address");
        System.out.println("0)----  Exit and Save");
        System.out.println();
        System.out.println("Please select and option (1,2,3,4,5,6,7, or 0");
        System.out.println();
        option = kb.nextInt();
        return option;
     }
     
     //method below starts the user account management screen
     public static void startUserAccountMangement() throws Exception{
        int option = userAccountManagement();

            objUserAccountList.load();
        
        while(option != 0){
            if(option == 0) {
                break;
            }
            switch(option) {
                case 1:
                    searchUserAccountRecord();
                    break;
                case 2:
                    addUserAccountRecordMethod1();
                    break;
                case 3:
                    editUserAccountRecordMethod1();
                    break;
                case 4:
                    removeUserAccountRecord();
                    break;
                case 5:
                    changeUserName();
                    break;
                case 6:
                    changePassword();
                    break;
                case 7:
                    changeEmail();
                    break;
                default:
                    System.out.println("Incorrect selection try again");
                break;
            }
            option = userAccountManagement();
            System.out.println();
        
        
        }
        System.out.println("exiting user Account management program.....");
        objUserAccountList.save();
        objUserAccountList.clear();
    }
     
     //Employee management screen
     public static int employeeManagement(){
         Scanner kb = new Scanner(System.in);
        int option;
        System.out.println();
        System.out.println("***Welcome to the Employee Management Portal****");
         System.out.println("----------------------------------------------------");
        System.out.println("1)---- Search for Employee recored");
        System.out.println("2)----  Add a Employee Record");
        System.out.println("3)----  Edit Employee Recored");
        System.out.println("4)----  Remove Employee Decored ");
        System.out.println("5)----  Print Employee Record");
        System.out.println("6)----  Print All Employee Records");
        System.out.println("0)----  Exit and Save");
        System.out.println();
        System.out.println("Please select and option (1,2,3,4,5,6, or 0");
        System.out.println();
        option = kb.nextInt();
        return option;
     }
     
     //method below strts the Employee management screen
     public static void startEmployeeManagement() throws Exception{
         int option = employeeManagement();
              objEmployeeList.load();
         while(option != 0) {
            
                 switch(option) {
                 case 1:
                     searchEmployeeRecord();
                     break;
                 case 2:
                     addEmployeeRecordmethod2();
                     break;
                 case 3:
                     editEmployeeRecord();
                     break;
                 case 4:
                     removeEmployeeRecord();
                     break;
                 case 5:
                     printEmployeeRecord();
                     break;
                 case 6:
                     printAllEmployeeRecords();
                     break;
                 default:
                     System.out.println("IncorrectSelection");
                     break;
               }
             option = employeeManagement();
             System.out.println();
        } 
         
         System.out.println("Exiting Employee Managementscreen......");
         objEmployeeList.save();
         objEmployeeList.clear();
     }
 
    
//Methods used for UserAccount management
//********************************************************************************
     
     // search for an UserAccount record
    public static void searchUserAccountRecord(){
        try{
            Scanner kb = new Scanner(System.in);
            String userName;
            System.out.println("****Searching user Account record****");
            System.out.println("Please enter the user name to search a record.");
            userName = kb.nextLine();

            UserAccount objUserAccount;
            objUserAccount = objUserAccountList.search(userName);

            if(objUserAccount != null) {
                System.out.println("*****Search Result*****");
                System.out.println("User Account Id: "+objUserAccount.getUserAccountID());
                System.out.println("User Name: "+objUserAccount.getUserName());
                System.out.println("Email: "+objUserAccount.getPassword());
                System.out.println("Email: "+objUserAccount.getEmail());

            } else {
                System.out.println();
                System.out.println("User Account record  not found...");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println();
            System.out.println("User Account record  not found...");
            System.out.println(e.toString());
        }
    }
    
    //add UserAccount record
    public static void addUserAccountRecordMethod1(){
        try{
            Scanner kb = new Scanner(System.in);
            boolean success;
            String userAccountID, username,email,password;
            System.out.println("****Adding new user Account record****");
            System.out.println("***Please enter the following information to add a user account record****");
            System.out.println();
            System.out.println("Enter UserName");
            username = kb.nextLine();
            System.out.println("Enter Password");
            password = kb.nextLine();
            System.out.println("Enter Email");
            email = kb.nextLine();
            System.out.println();

            UserAccount objNewUserAccount;
            objNewUserAccount = UserAccount.getInstance(username,password,email);

            success = objUserAccountList.add(objNewUserAccount);
            if(success){
                System.out.println("User account record has been Added succesfully!");
                System.out.println();
            }else{
                System.out.println("No vailable space to add arecord.");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
        
    }
    
    //add UserAccount record by passing values
    public static void addUserAccountRecordMethod2(){
        try{
            Scanner kb = new Scanner(System.in);
            boolean success;
            String userAccountID, userName,email,password;
            System.out.println("****Adding new user Account record****");
            System.out.println("***Please enter the following information to add a user account record****");
            System.out.println();
            System.out.println("Enter UserName");
            userName= kb.nextLine();
            System.out.println("Enter Password");
            password = kb.nextLine();
            System.out.println("Enter Email");
            email = kb.nextLine();
            System.out.println();

            objUserAccountList.add(userName, password, email);

            success = objUserAccountList.add(userName, password, email);
            if(success){
                System.out.println("User account record has been Added succesfully!");
                System.out.println();
            }else{
                System.out.println("No vailable space to add arecord.");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }
    
    //edit an UserAccount record
    public static void editUserAccountRecordMethod1(){
        try{
            Scanner kb = new Scanner(System.in);
            boolean success;
            String userName,newPassword,newEmail;
            System.out.println("****Editing new user Account record****");
            System.out.println("****Please enter the following information to edit a record****");
            System.out.println("Enter the UserName");
            userName = kb.nextLine();
            System.out.println("Enter the the New Password");
            newPassword = kb.nextLine();
            System.out.println("*Enter the new email");
            newEmail = kb.nextLine();
            System.out.println();

            UserAccount objUserAccount;
            objUserAccount = UserAccount.getInstance();
            objUserAccount.setPassword(newPassword);
            objUserAccount.setEmail(newEmail);

            success = objUserAccountList.edit(userName, objUserAccount);
            if(success) {
                System.out.print("User account record has been modified.");
                System.out.println();
            }else {
                System.out.print("User Account Record not found.");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }
    
    //Edit an UserAccount record by passing values
    public static void editUserAccountRecordMethod2(){
        try{
            Scanner kb = new Scanner(System.in);
            boolean success;
            String userName,newPassword,newEmail;
            System.out.println("****Editing new user Account record****");
            System.out.println("****Please enter the following information to edit a record****");
            System.out.println("Enter the UserName");
            userName = kb.nextLine();
            System.out.println("Enter the the New Password");
            newPassword = kb.nextLine();
            System.out.println("*Enter the new email");
            newEmail = kb.nextLine();
            System.out.println();

            UserAccount objUserAccount;
            objUserAccount = UserAccount.getInstance();
            objUserAccount.setPassword(newPassword);
            objUserAccount.setEmail(newEmail);

            success = objUserAccountList.edit(userName, newPassword, newEmail);
            if(success) {
                System.out.print("User account record has been modified.");
                System.out.println();
            }else {
                System.out.print("User Account Record not found.");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }
    
    //remove an UserAccount record
    public static void removeUserAccountRecord() {
        try{
            Scanner kb = new Scanner(System.in);
            String userName;
            boolean success;
            System.out.println("****Removing new user Account record****");
            System.out.println("****Please Enter the following information to remove a user account record****");
            System.out.println("Please enter the user Name.");
            userName = kb.nextLine();

            success = objUserAccountList.remove(userName);

            if(success) {
                System.out.println("User Account record removed successfully.");
                System.out.println();
            }else {
                System.out.println("User account Record not found.");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }
    
    //chnage user name of user account record
    public static void changeUserName() {
        try{
            String oldUserName, newUserName;
            boolean success;
            Scanner kb = new Scanner(System.in);
            System.out.println("****Changing new user Account record****");
            System.out.println("****Please enter the following information to change a user name");
            System.out.println("Please enter the old user name.");
            oldUserName = kb.nextLine();
            System.out.println("Please enter the new user name.");
            newUserName = kb.nextLine();
            System.out.println();

            success = objUserAccountList.changeUsername(oldUserName, newUserName);
            if(success) {
                System.out.println("User name chnged successfully!");
                System.out.println();
            }else {
                System.out.println("User Account Record not Found.");
                System.out.println();
            }
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }
    
    ////chnage password of user account record
    public static void changePassword() {
        try{
           String userName, newPassword;
            boolean success;
            Scanner kb = new Scanner(System.in);

            System.out.println("****Please enter the following information to change password");
            System.out.println("Please enter the  user name.");
            userName = kb.nextLine();
            System.out.println("Please enter the new Password.");
            newPassword= kb.nextLine();
            System.out.println();

            success = objUserAccountList.changePassword(userName, newPassword);
            if(success) {
                System.out.println("Password chnged successfully!");
                System.out.println();
            }else {
                System.out.println("User Account Record not Found.");
                System.out.println();
            } 
        }
        catch(Exception e) {
            System.out.println(e.toString());
        }
    }
    
    //chnage Email of user account record
    public static void changeEmail() {
        try{
            String userName, newEmail;
            boolean success;
            Scanner kb = new Scanner(System.in);

            System.out.println("****Please enter the following information to change an Email");
            System.out.println("Please enter the user name.");
            userName = kb.nextLine();
            System.out.println("Please enter the new Email.");
            newEmail= kb.nextLine();
            System.out.println();

            success = objUserAccountList.changeEmail(userName, newEmail);
            if(success) {
                System.out.println("Email chnged successfully!");
                System.out.println();
            }else {
                System.out.println("User Account Record not Found.");
                System.out.println();
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
        
    }
 //********************************************************************************
    
  //method used for Employee Management
    
    //search for employee record
    public static void searchEmployeeRecord(){
        try{
            String SSN;
        
            Scanner kb = new Scanner(System.in);
            System.out.println("Please enter the Social Security Number to search an employee Record");
            SSN = kb.nextLine();

            Employee objEmployee;
            objEmployee = objEmployeeList.search(SSN);

            if(objEmployee != null) {
                System.out.println("*****Search Result*****");
                System.out.println("-----------------------");
                System.out.println("First Name: "+objEmployee.getFirstName());
                System.out.println("Last Name: "+objEmployee.getLastName());
                System.out.println("User Account Id: "+objEmployee.getSSNumber());
                System.out.println("Date of Birth: "+objEmployee.getDateOfBirth());
                System.out.println("Address: "+objEmployee.getAddress());
                System.out.println("Phone Number: "+objEmployee.getPhone());
                System.out.println("Age: "+objEmployee.getAge());
                System.out.println("Email "+objEmployee.getEmail());
                System.out.println("Title: "+objEmployee.getJobTitle());

            }
            else {
                System.out.println();
                System.out.println("Employee record  not found...");
                System.out.println();
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
    
    //add an employee record
    public static void addEmployeeRecord(){
        try{
            boolean success;
            String SSN,fName,lName,dob,address,phone,email,title;

           Scanner kb = new Scanner(System.in);
           System.out.println("Adding a new employee Record");
           System.out.println("Enter Social Security Number");
           SSN = kb.nextLine();
           System.out.println("Enter the First Name");
           fName = kb.nextLine();
           System.out.println("Enter The Last Name");
           lName = kb.nextLine();
           System.out.println("Enter Date of Birth in MM/DD/YYYY Form");
           dob = kb.nextLine();
           System.out.println("Enter The Address");
           address = kb.nextLine();
           System.out.println("Enter The Phone Number");
           phone = kb.nextLine();
           System.out.println("Enter The Email Address");
           email = kb.nextLine();
           System.out.println("Enter The Job Title");
           title = kb.nextLine();

           Employee newEmployeeObj = new Employee(SSN,fName,lName,dob,address,phone,email,title);
           success = objEmployeeList.add(newEmployeeObj);

           if(success) {
               System.out.println();
               System.out.println("Employee Record has been added succesfully");
           }else{
               System.out.println();
               System.out.println("No Available space to add an employee record");
           }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
        
    }
    
    //add an employee record by passing values
    public static void addEmployeeRecordmethod2(){
        try{
            boolean success;
            String SSN,fName,lName,dob,address,phone,email,title;

           Scanner kb = new Scanner(System.in);
           System.out.println("Adding a new employee Record");
           System.out.println("Enter Social Security Number");
           SSN = kb.nextLine();
           System.out.println("Enter the First Name");
           fName = kb.nextLine();
           System.out.println("Enter The Last Name");
           lName = kb.nextLine();
           System.out.println("Enter Date of Birth in MM/DD/YYYY Form");
           dob = kb.nextLine();
           System.out.println("Enter The Address");
           address = kb.nextLine();
           System.out.println("Enter The Phone Number");
           phone = kb.nextLine();
           System.out.println("Enter The Email Address");
           email = kb.nextLine();
           System.out.println("Enter The Job Title");
           title = kb.nextLine();

           success = objEmployeeList.add(SSN,fName,lName,dob,address,phone,email,title);

           if(success) {
               System.out.println();
               System.out.println("Employee Record has been added succesfully");
           }else{
               System.out.println();
               System.out.println("No Available space to add an employee record");
           }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }        
    }
    
    //Edit an employee record
    public static void editEmployeeRecord(){
        try{
            boolean success;
            String SSN,fName,lName,dob,address,phone,email,title;
            
            Scanner kb = new Scanner(System.in);
            System.out.println("****Editing employee Record*****");
            System.out.println("Enter Social Security Number");
            SSN = kb.nextLine();
            System.out.println("Enter the First Name");
            fName = kb.nextLine();
            System.out.println("Enter The Last Name");
            lName = kb.nextLine();
            System.out.println("Enter Date of Birth in MM/DD/YYYY Form");
            dob = kb.nextLine();
            System.out.println("Enter The Address");
            address = kb.nextLine();
            System.out.println("Enter The Phone Number");
            phone = kb.nextLine();
            System.out.println("Enter The Email Address");
            email = kb.nextLine();
            System.out.println("Enter The Job Title");
            title = kb.nextLine();
            
            Employee objEmployee = new Employee();
            
            objEmployee.setFirstName(fName);
            objEmployee.setLastName(lName);
            objEmployee.setDateOfBirth(dob);
            objEmployee.setAddress(address);
            objEmployee.setPhone(phone);
            objEmployee.setEmail(email);
            objEmployee.setJobTitle(title);
            
            success = objEmployeeList.edit(SSN,objEmployee);
            if(success){
                System.out.println();
                System.out.println("Employee Record Has Been Modified Successfully!");
            }
            else{
                System.out.println();
                System.out.println("Employee Record not Found");
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
    
    //edit an employee record by passing values
    public static void editEmployeeRecordMethod2(){
        try{
            boolean success;
            String SSN,fName,lName,dob,address,phone,email,title;
            
            Scanner kb = new Scanner(System.in);
            System.out.println("****Editing employee Record*****");
            System.out.println("Enter Social Security Number");
            SSN = kb.nextLine();
            System.out.println("Enter the First Name");
            fName = kb.nextLine();
            System.out.println("Enter The Last Name");
            lName = kb.nextLine();
            System.out.println("Enter Date of Birth in MM/DD/YYYY Form");
            dob = kb.nextLine();
            System.out.println("Enter The Address");
            address = kb.nextLine();
            System.out.println("Enter The Phone Number");
            phone = kb.nextLine();
            System.out.println("Enter The Email Address");
            email = kb.nextLine();
            System.out.println("Enter The Job Title");
            title = kb.nextLine();
            
            Employee objEmployee = new Employee();
            
            success = objEmployeeList.edit(SSN, fName, lName, dob, address, phone, email, title);
            if(success){
                System.out.println();
                System.out.println("Employee Record Has Been Modified Successfully!");
            }
            else{
                System.out.println();
                System.out.println("Employee Record not Found");
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
    
    //remove an employee record
    public static void removeEmployeeRecord(){
        try{
            boolean success;
            String SSN;
            
            Scanner kb = new Scanner(System.in);
            System.out.println("****Removing employee Record*****");
            System.out.println("Enter Social Security Number");
            SSN = kb.nextLine();
            
            success = objEmployeeList.remove(SSN);
            if(success){
                System.out.println();
                System.out.println("Employee Record Has Been Removed Successfully!");
            }
            else{
                System.out.println();
                System.out.println("Employee Record not Found");
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
    
    //print a specofic  employee record
    public static void printEmployeeRecord(){
        try{
             boolean success;
            String SSN;
            
            Scanner kb = new Scanner(System.in);
            System.out.println("****Printing employee Record*****");
            System.out.println("Enter Social Security Number");
            SSN = kb.nextLine();
            success = objEmployeeList.print(SSN);
            
            if(success){
                System.out.println();
                System.out.println("Record printed successfully");
            }
            else{
                System.out.println();
                System.out.println("Employee Record Not Found");
            }
        }
        catch(Exception e){
            
            System.out.println(e.toString());
        }
    }
    
    //print all employee records
    public static void printAllEmployeeRecords(){
        try{
            objEmployeeList.printAll();
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
}